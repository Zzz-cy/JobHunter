/**
 * 统一 HTTP 请求工具
 * - 自动处理前缀（Vite 代理 / 环境变量）
 * - 统一错误处理
 * - JSON 序列化/反序列化
 */

const BASE_URL = import.meta.env.VITE_API_BASE_URL || ''

async function request(url, options = {}) {
  const resp = await fetch(`${BASE_URL}${url}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  })
  if (!resp.ok) {
    const text = await resp.text()
    throw new Error(`HTTP ${resp.status}: ${resp.statusText}\n${text}`)
  }
  return resp.json()
}

/** GET 请求 */
export function get(url, params) {
  const query = params ? '?' + new URLSearchParams(params).toString() : ''
  return request(`${url}${query}`)
}

/** POST 请求 */
export function post(url, data) {
  return request(url, { method: 'POST', body: JSON.stringify(data) })
}
