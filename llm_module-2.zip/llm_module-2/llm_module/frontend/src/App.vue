<template>
  <div id="app-root">
    <router-view />
  </div>
</template>

<script setup>
import { RouterView } from 'vue-router'
</script>

<style>
#app-root {
  min-height: 100vh;
}
</style>
