/**
 * API 封装模块
 * 开发环境通过 Vite proxy 转发到 localhost:5173
 * 生产环境通过 VITE_API_BASE_URL 环境变量配置
 */

const API_BASE = import.meta.env.VITE_API_BASE_URL || ''

async function request(url, options = {}) {
  const resp = await fetch(`${API_BASE}${url}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  })
  if (!resp.ok) {
    const text = await resp.text()
    throw new Error(`HTTP ${resp.status}: ${resp.statusText}\n${text}`)
  }
  return resp.json()
}

/** 获取模型状态 */
export function getModelStatus() {
  return request('/agents/model-status')
}

/** 发送聊天消息 */
export function sendChatMessage({ message, session_id, industry, role }) {
  return request('/agents/chat', {
    method: 'POST',
    body: JSON.stringify({ message, session_id, industry, role }),
  })
}

/** 获取管理后台监控指标 */
export function getAdminMetrics() {
  return request('/api/v1/admin/metrics')
}

/** 获取追踪详情 */
export function getTraceDetail(traceId) {
  return request(`/api/v1/admin/traces/${traceId}`)
}

/** 获取告警数据 */
export function getAlerts() {
  return request('/api/v1/admin/alerts')
}
