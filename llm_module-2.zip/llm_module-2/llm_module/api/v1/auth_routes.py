"""
认证API路由 - 用户注册、登录、令牌刷新、用户信息
"""
from __future__ import annotations

import re
from typing import Optional
from datetime import datetime

from fastapi import APIRouter, Request, Depends
from pydantic import BaseModel, Field

from utils.logger import get_logger
logger = get_logger("api.v1.auth_routes")


# ==================== 请求模型 ====================

class RegisterRequest(BaseModel):
    """注册请求"""
    username: str = Field(..., min_length=3, max_length=50,
                          description="用户名（字母数字下划线）")
    password: str = Field(..., min_length=6, max_length=100,
                          description="密码（至少6位）")
    email: Optional[str] = Field(None, description="邮箱")
    industry: Optional[str] = Field(None, description="行业 (it/finance/healthcare/manufacturing/education)")
    role: Optional[str] = Field(None, description="角色 (job_seeker/hr/career_planner/manager)")


class LoginRequest(BaseModel):
    """登录请求"""
    username: str = Field(..., description="用户名")
    password: str = Field(..., description="密码")


class RefreshRequest(BaseModel):
    """刷新令牌请求"""
    refresh_token: str = Field(..., description="刷新令牌")


# ==================== 响应辅助 ====================

def success_response(data=None, message="success", request_id="") -> dict:
    """构建成功响应"""
    return {
        "code": 0,
        "message": message,
        "data": data,
        "request_id": request_id,
        "timestamp": datetime.now().isoformat(),
    }


def error_response(code: int, message: str, request_id: str = "") -> dict:
    """构建错误响应"""
    return {
        "code": code,
        "message": message,
        "data": None,
        "request_id": request_id,
        "timestamp": datetime.now().isoformat(),
    }


# ==================== 路由 ====================

router = APIRouter(prefix="/api/v1/auth", tags=["Authentication"])


@router.post("/register")
async def register(request: RegisterRequest, req: Request):
    """用户注册"""
    from services.auth_service import get_auth_service
    from services.db_service import get_db_service

    request_id = req.headers.get("X-Request-ID", "")

    # 校验用户名格式
    if not re.match(r'^[a-zA-Z0-9_一-鿿]+$', request.username):
        return error_response(400, "用户名只能包含字母、数字、下划线和中文", request_id)

    auth = get_auth_service()
    db = get_db_service()

    # 检查用户名是否已存在
    existing = db.get_user_by_username(request.username)
    if existing:
        return error_response(409, "用户名已存在", request_id)

    # 哈希密码
    try:
        password_hash = auth.hash_password(request.password)
    except RuntimeError as e:
        return error_response(500, f"密码哈希失败: {e}", request_id)

    # 创建用户
    try:
        user_id = db.create_user(
            username=request.username,
            password_hash=password_hash,
            email=request.email or "",
            industry=request.industry or "",
            role=request.role or "job_seeker",
        )
    except Exception as e:
        logger.error(f"创建用户失败: {e}")
        return error_response(500, f"创建用户失败: {e}", request_id)

    # 生成令牌
    access_token = auth.create_access_token(user_id, request.username, request.role or "job_seeker")
    refresh_token = auth.create_refresh_token(user_id)

    return success_response({
        "user_id": user_id,
        "username": request.username,
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "expires_in": auth._access_token_expire_minutes * 60,
    }, message="注册成功", request_id=request_id)


@router.post("/login")
async def login(request: LoginRequest, req: Request):
    """用户登录"""
    from services.auth_service import get_auth_service
    from services.db_service import get_db_service

    request_id = req.headers.get("X-Request-ID", "")

    auth = get_auth_service()
    db = get_db_service()

    # 查找用户
    user = db.get_user_by_username(request.username)
    if not user:
        return error_response(401, "用户名或密码错误", request_id)

    # 检查用户是否活跃
    if not user.get("is_active", 1):
        return error_response(403, "用户已被禁用", request_id)

    # 验证密码
    if not auth.verify_password(request.password, user["password_hash"]):
        return error_response(401, "用户名或密码错误", request_id)

    # 生成令牌
    access_token = auth.create_access_token(user["id"], user["username"], user.get("role", "job_seeker"))
    refresh_token = auth.create_refresh_token(user["id"])

    return success_response({
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "expires_in": auth._access_token_expire_minutes * 60,
        "user": {
            "user_id": user["id"],
            "username": user["username"],
            "role": user.get("role", "job_seeker"),
            "industry": user.get("industry", ""),
        },
    }, message="登录成功", request_id=request_id)


@router.post("/refresh")
async def refresh(request: RefreshRequest, req: Request):
    """刷新访问令牌"""
    from services.auth_service import get_auth_service

    request_id = req.headers.get("X-Request-ID", "")

    auth = get_auth_service()
    result = auth.refresh_access_token(request.refresh_token)

    if not result:
        return error_response(401, "刷新令牌无效或已过期", request_id)

    return success_response(result, request_id=request_id)


@router.get("/me")
async def get_me(req: Request):
    """获取当前用户信息（需认证）"""
    from services.auth_service import get_auth_service
    from services.db_service import get_db_service

    request_id = req.headers.get("X-Request-ID", "")

    auth = get_auth_service()
    current_user = await auth.get_current_user(req)

    db = get_db_service()
    user = db.get_user_by_id(current_user["user_id"])

    if not user:
        return error_response(404, "用户不存在", request_id)

    return success_response({
        "user_id": user["id"],
        "username": user["username"],
        "email": user.get("email", ""),
        "industry": user.get("industry", ""),
        "role": user.get("role", "job_seeker"),
        "created_at": str(user.get("created_at", "")),
    }, request_id=request_id)
