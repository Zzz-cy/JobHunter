"""
MySQL数据库服务 - 存储结构化数据
支持岗位、技能、能力等实体及关系
"""
import json
import sqlite3
from typing import List, Dict, Optional, Any
from datetime import datetime
from dataclasses import dataclass

from utils.config import MYSQL_CONFIG, SQLITE_PATH
from utils.logger import get_logger
logger = get_logger("services.db_service")

# 尝试导入MySQL驱动
try:
    import pymysql
    MYSQL_AVAILABLE = True
except ImportError:
    MYSQL_AVAILABLE = False
    logger.warning("pymysql未安装，将使用SQLite")


@dataclass
class JobEntity:
    """岗位实体"""
    id: Optional[int] = None
    name: str = ""
    category: str = ""
    description: str = ""
    requirements: str = ""
    salary_range: str = ""
    location: str = ""
    source: str = ""
    created_at: Optional[str] = None


@dataclass
class SkillEntity:
    """技能实体"""
    id: Optional[int] = None
    name: str = ""
    category: str = ""
    description: str = ""
    level: str = ""  # beginner, intermediate, advanced
    related_jobs: str = ""  # JSON数组
    created_at: Optional[str] = None


@dataclass
class CompetencyRelation:
    """能力关系"""
    id: Optional[int] = None
    source_type: str = ""  # job, skill
    source_name: str = ""
    target_type: str = ""  # job, skill
    target_name: str = ""
    relation_type: str = ""  # requires, prerequisite, related
    weight: float = 1.0
    created_at: Optional[str] = None


class DatabaseService:
    """数据库服务 - 支持MySQL和SQLite"""

    def __init__(self):
        self.use_mysql = MYSQL_AVAILABLE and self._test_mysql_connection()
        self.conn = None
        self.cursor = None

        # MySQL使用%s占位符，SQLite使用?占位符
        self._placeholder = "%s" if self.use_mysql else "?"

        if self.use_mysql:
            self._init_mysql()
        else:
            self._init_sqlite()

        self._create_tables()

    def _q(self, sql: str) -> str:
        """将SQL中的?占位符转换为当前数据库的占位符"""
        if self._placeholder == "?":
            return sql
        return sql.replace("?", "%s")

    def _test_mysql_connection(self) -> bool:
        """测试MySQL连接"""
        try:
            conn = pymysql.connect(
                host=MYSQL_CONFIG["host"],
                port=MYSQL_CONFIG["port"],
                user=MYSQL_CONFIG["user"],
                password=MYSQL_CONFIG["password"],
                database=MYSQL_CONFIG["database"],
                connect_timeout=3,  # 3秒超时，避免启动卡住
            )
            conn.close()
            return True
        except Exception as e:
            logger.warning(f"MySQL连接失败: {e}")
            return False

    def _init_mysql(self):
        """初始化MySQL连接"""
        try:
            self.conn = pymysql.connect(
                host=MYSQL_CONFIG["host"],
                port=MYSQL_CONFIG["port"],
                user=MYSQL_CONFIG["user"],
                password=MYSQL_CONFIG["password"],
                database=MYSQL_CONFIG["database"],
                charset='utf8mb4',
                cursorclass=pymysql.cursors.DictCursor,
            )
            self.cursor = self.conn.cursor()
            logger.info(f"MySQL连接成功: {MYSQL_CONFIG['host']}:{MYSQL_CONFIG['port']}")
        except Exception as e:
            logger.error(f"MySQL初始化失败: {e}")
            self.use_mysql = False
            self._init_sqlite()

    def _init_sqlite(self):
        """初始化SQLite连接"""
        import os
        os.makedirs(os.path.dirname(SQLITE_PATH), exist_ok=True)
        self.conn = sqlite3.connect(SQLITE_PATH, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.cursor = self.conn.cursor()
        logger.info(f"SQLite连接成功: {SQLITE_PATH}")

    def _create_tables(self):
        """创建数据表"""
        # MySQL和SQLite的DDL差异：AUTO_INCREMENT vs AUTOINCREMENT
        auto_inc = "AUTO_INCREMENT" if self.use_mysql else "AUTOINCREMENT"

        # 岗位表
        self.cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY {auto_inc},
                name VARCHAR(255) NOT NULL,
                category VARCHAR(100),
                description TEXT,
                requirements TEXT,
                salary_range VARCHAR(100),
                location VARCHAR(100),
                source VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # 技能表
        self.cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS skills (
                id INTEGER PRIMARY KEY {auto_inc},
                name VARCHAR(255) NOT NULL,
                category VARCHAR(100),
                description TEXT,
                level VARCHAR(50),
                related_jobs TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # 关系表
        self.cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS relations (
                id INTEGER PRIMARY KEY {auto_inc},
                source_type VARCHAR(50) NOT NULL,
                source_name VARCHAR(255) NOT NULL,
                target_type VARCHAR(50) NOT NULL,
                target_name VARCHAR(255) NOT NULL,
                relation_type VARCHAR(50) NOT NULL,
                weight REAL DEFAULT 1.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # ==================== 第四阶段扩展表 ====================

        # 用户表
        self.cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY {auto_inc},
                username VARCHAR(100) NOT NULL UNIQUE,
                password_hash VARCHAR(255) NOT NULL,
                email VARCHAR(255),
                industry VARCHAR(50) DEFAULT '',
                role VARCHAR(50) DEFAULT 'job_seeker',
                is_active INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # 会话持久化表
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS sessions_db (
                id VARCHAR(50) PRIMARY KEY,
                user_id INTEGER,
                title VARCHAR(255) DEFAULT '',
                industry_context VARCHAR(50) DEFAULT '',
                role VARCHAR(50) DEFAULT 'job_seeker',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # 消息表
        self.cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY {auto_inc},
                session_id VARCHAR(50) NOT NULL,
                role VARCHAR(20) NOT NULL,
                content TEXT NOT NULL,
                intent VARCHAR(50),
                agent_tasks TEXT,
                latency_ms REAL DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Agent执行记录表
        self.cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS agent_executions (
                id INTEGER PRIMARY KEY {auto_inc},
                request_id VARCHAR(50),
                session_id VARCHAR(50),
                intent VARCHAR(50),
                task_type VARCHAR(50),
                model_used VARCHAR(100),
                input_tokens INTEGER DEFAULT 0,
                output_tokens INTEGER DEFAULT 0,
                cost REAL DEFAULT 0,
                latency_ms REAL DEFAULT 0,
                status VARCHAR(20) DEFAULT 'pending',
                retry_count INTEGER DEFAULT 0,
                error_message TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # 技能库表
        self.cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS skill_taxonomy (
                id INTEGER PRIMARY KEY {auto_inc},
                name VARCHAR(255) NOT NULL,
                category VARCHAR(100),
                industry VARCHAR(50),
                level VARCHAR(50),
                description TEXT,
                source VARCHAR(100) DEFAULT 'manual',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # 行业配置表
        self.cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS industry_configs (
                id INTEGER PRIMARY KEY {auto_inc},
                industry_code VARCHAR(50) NOT NULL UNIQUE,
                industry_name VARCHAR(100) NOT NULL,
                skill_categories TEXT,
                prompt_overrides TEXT,
                extraction_keywords TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # 评估表
        self.cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS evaluations (
                id INTEGER PRIMARY KEY {auto_inc},
                message_id INTEGER,
                user_id INTEGER,
                auto_score REAL DEFAULT 0,
                user_score REAL DEFAULT 0,
                user_feedback TEXT,
                intent_accuracy REAL DEFAULT 0,
                task_completion REAL DEFAULT 0,
                response_quality REAL DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # 监控指标表
        self.cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS metrics (
                id INTEGER PRIMARY KEY {auto_inc},
                metric_name VARCHAR(100) NOT NULL,
                metric_value REAL NOT NULL,
                labels_json TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # 用户资源配额表
        self.cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS user_quotas (
                id INTEGER PRIMARY KEY {auto_inc},
                user_id INTEGER NOT NULL,
                daily_calls INTEGER DEFAULT 0,
                daily_tokens INTEGER DEFAULT 0,
                quota_date VARCHAR(10) NOT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # 创建索引
        if self.use_mysql:
            # MySQL不支持CREATE INDEX IF NOT EXISTS，用存储过程处理
            index_sqls = [
                ("idx_jobs_name", "CREATE INDEX idx_jobs_name ON jobs(name)"),
                ("idx_skills_name", "CREATE INDEX idx_skills_name ON skills(name)"),
                ("idx_relations_source", "CREATE INDEX idx_relations_source ON relations(source_name)"),
                ("idx_relations_target", "CREATE INDEX idx_relations_target ON relations(target_name)"),
                ("idx_messages_session", "CREATE INDEX idx_messages_session ON messages(session_id)"),
                ("idx_agent_exec_request", "CREATE INDEX idx_agent_exec_request ON agent_executions(request_id)"),
                ("idx_agent_exec_session", "CREATE INDEX idx_agent_exec_session ON agent_executions(session_id)"),
                ("idx_skill_taxonomy_industry", "CREATE INDEX idx_skill_taxonomy_industry ON skill_taxonomy(industry)"),
                ("idx_sessions_user_id", "CREATE INDEX idx_sessions_user_id ON sessions_db(user_id)"),
                ("idx_user_quotas_user_date", "CREATE INDEX idx_user_quotas_user_date ON user_quotas(user_id, quota_date)"),
            ]
            for idx_name, idx_sql in index_sqls:
                try:
                    self.cursor.execute(idx_sql)
                except Exception:
                    pass  # 索引已存在，忽略
        else:
            # SQLite支持CREATE INDEX IF NOT EXISTS
            self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_jobs_name ON jobs(name)")
            self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_skills_name ON skills(name)")
            self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_relations_source ON relations(source_name)")
            self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_relations_target ON relations(target_name)")
            self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id)")
            self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_agent_exec_request ON agent_executions(request_id)")
            self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_agent_exec_session ON agent_executions(session_id)")
            self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_skill_taxonomy_industry ON skill_taxonomy(industry)")
            self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions_db(user_id)")
            self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_user_quotas_user_date ON user_quotas(user_id, quota_date)")

        self.conn.commit()
        logger.info("数据表创建完成")

    # ========== 岗位操作 ==========

    def create_job(self, job: JobEntity) -> int:
        """创建岗位"""
        self.cursor.execute(self._q("""
            INSERT INTO jobs (name, category, description, requirements, salary_range, location, source)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """), (job.name, job.category, job.description, job.requirements,
              job.salary_range, job.location, job.source))
        self.conn.commit()
        return self.cursor.lastrowid

    def get_job(self, job_id: int) -> Optional[Dict]:
        """获取岗位"""
        self.cursor.execute(self._q("SELECT * FROM jobs WHERE id = ?"), (job_id,))
        row = self.cursor.fetchone()
        return dict(row) if row else None

    def search_jobs(self, keyword: str = "", category: str = "", limit: int = 100) -> List[Dict]:
        """搜索岗位"""
        sql = "SELECT * FROM jobs WHERE 1=1"
        params = []

        if keyword:
            sql += " AND (name LIKE ? OR description LIKE ?)"
            params.extend([f"%{keyword}%", f"%{keyword}%"])

        if category:
            sql += " AND category = ?"
            params.append(category)

        sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)

        self.cursor.execute(self._q(sql), params)
        return [dict(row) for row in self.cursor.fetchall()]

    # ========== 技能操作 ==========

    def create_skill(self, skill: SkillEntity) -> int:
        """创建技能"""
        self.cursor.execute(self._q("""
            INSERT INTO skills (name, category, description, level, related_jobs)
            VALUES (?, ?, ?, ?, ?)
        """), (skill.name, skill.category, skill.description, skill.level, skill.related_jobs))
        self.conn.commit()
        return self.cursor.lastrowid

    def get_skill(self, skill_id: int) -> Optional[Dict]:
        """获取技能"""
        self.cursor.execute(self._q("SELECT * FROM skills WHERE id = ?"), (skill_id,))
        row = self.cursor.fetchone()
        return dict(row) if row else None

    def search_skills(self, keyword: str = "", category: str = "", limit: int = 100) -> List[Dict]:
        """搜索技能"""
        sql = "SELECT * FROM skills WHERE 1=1"
        params = []

        if keyword:
            sql += " AND (name LIKE ? OR description LIKE ?)"
            params.extend([f"%{keyword}%", f"%{keyword}%"])

        if category:
            sql += " AND category = ?"
            params.append(category)

        sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)

        self.cursor.execute(self._q(sql), params)
        return [dict(row) for row in self.cursor.fetchall()]

    # ========== 关系操作 ==========

    def create_relation(self, relation: CompetencyRelation) -> int:
        """创建关系"""
        self.cursor.execute(self._q("""
            INSERT INTO relations (source_type, source_name, target_type, target_name, relation_type, weight)
            VALUES (?, ?, ?, ?, ?, ?)
        """), (relation.source_type, relation.source_name, relation.target_type,
              relation.target_name, relation.relation_type, relation.weight))
        self.conn.commit()
        return self.cursor.lastrowid

    def get_relations(self, source_name: str = "", target_name: str = "",
                     relation_type: str = "", limit: int = 100) -> List[Dict]:
        """获取关系"""
        sql = "SELECT * FROM relations WHERE 1=1"
        params = []

        if source_name:
            sql += " AND source_name = ?"
            params.append(source_name)

        if target_name:
            sql += " AND target_name = ?"
            params.append(target_name)

        if relation_type:
            sql += " AND relation_type = ?"
            params.append(relation_type)

        sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)

        self.cursor.execute(self._q(sql), params)
        return [dict(row) for row in self.cursor.fetchall()]

    def get_job_skills(self, job_name: str) -> List[Dict]:
        """获取岗位所需技能"""
        self.cursor.execute(self._q("""
            SELECT r.*, s.* FROM relations r
            LEFT JOIN skills s ON r.target_name = s.name
            WHERE r.source_name = ? AND r.relation_type = 'requires'
        """), (job_name,))
        return [dict(row) for row in self.cursor.fetchall()]

    # ========== 用户操作 ==========

    def create_user(self, username: str, password_hash: str, email: str = "",
                    industry: str = "", role: str = "job_seeker") -> int:
        """创建用户"""
        self.cursor.execute(self._q("""
            INSERT INTO users (username, password_hash, email, industry, role)
            VALUES (?, ?, ?, ?, ?)
        """), (username, password_hash, email, industry, role))
        self.conn.commit()
        return self.cursor.lastrowid

    def get_user_by_username(self, username: str) -> Optional[Dict]:
        """根据用户名获取用户"""
        self.cursor.execute(self._q("SELECT * FROM users WHERE username = ?"), (username,))
        row = self.cursor.fetchone()
        return dict(row) if row else None

    def get_user_by_id(self, user_id: int) -> Optional[Dict]:
        """根据ID获取用户"""
        self.cursor.execute(self._q("SELECT * FROM users WHERE id = ?"), (user_id,))
        row = self.cursor.fetchone()
        return dict(row) if row else None

    def update_user(self, user_id: int, email: str = "", industry: str = "",
                    role: str = "") -> bool:
        """更新用户信息"""
        try:
            updates = []
            params = []
            if email:
                updates.append("email = ?")
                params.append(email)
            if industry:
                updates.append("industry = ?")
                params.append(industry)
            if role:
                updates.append("role = ?")
                params.append(role)
            updates.append("updated_at = CURRENT_TIMESTAMP")
            params.append(user_id)
            self.cursor.execute(
                self._q(f"UPDATE users SET {', '.join(updates)} WHERE id = ?"),
                params
            )
            self.conn.commit()
            return True
        except Exception as e:
            logger.error(f"更新用户失败: {e}")
            return False

    # ========== 用户配额操作 ==========

    def list_sessions_by_user(self, user_id: int, limit: int = 100) -> List[Dict]:
        """列出指定用户的会话"""
        try:
            self.cursor.execute(
                self._q("SELECT * FROM sessions_db WHERE user_id = ? ORDER BY updated_at DESC LIMIT ?"),
                (user_id, limit)
            )
            return [dict(row) for row in self.cursor.fetchall()]
        except Exception as e:
            logger.error(f"列出用户会话失败: {e}")
            return []

    def get_user_daily_usage(self, user_id: int, date: str = "") -> Optional[Dict]:
        """获取用户每日使用量"""
        if not date:
            date = datetime.now().strftime("%Y-%m-%d")
        try:
            self.cursor.execute(self._q(
                "SELECT * FROM user_quotas WHERE user_id = ? AND quota_date = ?"
            ), (user_id, date))
            row = self.cursor.fetchone()
            return dict(row) if row else None
        except Exception as e:
            logger.error(f"获取用户配额失败: {e}")
            return None

    def upsert_user_usage(self, user_id: int, date: str, daily_calls: int = 0,
                          daily_tokens: int = 0) -> bool:
        """插入或更新用户每日使用量"""
        try:
            if self.use_mysql:
                self.cursor.execute(self._q("""
                    INSERT INTO user_quotas (user_id, daily_calls, daily_tokens, quota_date, updated_at)
                    VALUES (%s, %s, %s, %s, CURRENT_TIMESTAMP)
                    ON DUPLICATE KEY UPDATE
                        daily_calls = VALUES(daily_calls),
                        daily_tokens = VALUES(daily_tokens),
                        updated_at = CURRENT_TIMESTAMP
                """), (user_id, daily_calls, daily_tokens, date))
            else:
                self.cursor.execute(self._q("""
                    INSERT OR REPLACE INTO user_quotas (user_id, daily_calls, daily_tokens, quota_date, updated_at)
                    VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
                """), (user_id, daily_calls, daily_tokens, date))
            self.conn.commit()
            return True
        except Exception as e:
            logger.error(f"更新用户配额失败: {e}")
            return False

    # ========== 统计 ==========

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        self.cursor.execute("SELECT COUNT(*) as count FROM jobs")
        job_count = self.cursor.fetchone()["count"]

        self.cursor.execute("SELECT COUNT(*) as count FROM skills")
        skill_count = self.cursor.fetchone()["count"]

        self.cursor.execute("SELECT COUNT(*) as count FROM relations")
        relation_count = self.cursor.fetchone()["count"]

        return {
            "jobs": job_count,
            "skills": skill_count,
            "relations": relation_count,
            "database": "MySQL" if self.use_mysql else "SQLite",
        }

    # ========== 会话持久化操作 ==========

    def create_session_db(self, session_id: str, industry: str = "", role: str = "",
                          title: str = "", user_id: int = 0) -> bool:
        """创建会话记录到数据库"""
        try:
            # MySQL不支持INSERT OR REPLACE，使用INSERT ... ON DUPLICATE KEY UPDATE
            if self.use_mysql:
                self.cursor.execute(self._q("""
                    INSERT INTO sessions_db (id, user_id, title, industry_context, role, created_at, updated_at)
                    VALUES (%s, %s, %s, %s, %s, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                    ON DUPLICATE KEY UPDATE
                        industry_context = VALUES(industry_context),
                        role = VALUES(role),
                        updated_at = CURRENT_TIMESTAMP
                """), (session_id, user_id, title, industry, role))
            else:
                self.cursor.execute(self._q("""
                    INSERT OR REPLACE INTO sessions_db (id, user_id, title, industry_context, role, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                """), (session_id, user_id, title, industry, role))
            self.conn.commit()
            return True
        except Exception as e:
            logger.error(f"创建会话记录失败: {e}")
            return False

    def get_session_db(self, session_id: str) -> Optional[Dict]:
        """从数据库获取会话"""
        try:
            self.cursor.execute(self._q("SELECT * FROM sessions_db WHERE id = ?"), (session_id,))
            row = self.cursor.fetchone()
            return dict(row) if row else None
        except Exception as e:
            logger.error(f"获取会话记录失败: {e}")
            return None

    def update_session_db(self, session_id: str, industry: str = "", role: str = "") -> bool:
        """更新会话记录"""
        try:
            updates = []
            params = []
            if industry:
                updates.append("industry_context = ?")
                params.append(industry)
            if role:
                updates.append("role = ?")
                params.append(role)
            updates.append("updated_at = CURRENT_TIMESTAMP")
            params.append(session_id)
            self.cursor.execute(
                self._q(f"UPDATE sessions_db SET {', '.join(updates)} WHERE id = ?"),
                params
            )
            self.conn.commit()
            return True
        except Exception as e:
            logger.error(f"更新会话记录失败: {e}")
            return False

    def delete_session_db(self, session_id: str) -> bool:
        """从数据库删除会话"""
        try:
            self.cursor.execute(self._q("DELETE FROM sessions_db WHERE id = ?"), (session_id,))
            # 同时删除该会话的消息
            self.cursor.execute(self._q("DELETE FROM messages WHERE session_id = ?"), (session_id,))
            self.conn.commit()
            return True
        except Exception as e:
            logger.error(f"删除会话记录失败: {e}")
            return False

    def list_sessions_db(self, limit: int = 100) -> List[Dict]:
        """列出数据库中的所有会话"""
        try:
            self.cursor.execute(
                self._q("SELECT * FROM sessions_db ORDER BY updated_at DESC LIMIT ?"),
                (limit,)
            )
            return [dict(row) for row in self.cursor.fetchall()]
        except Exception as e:
            logger.error(f"列出会话记录失败: {e}")
            return []

    # ========== 消息操作 ==========

    def create_message(self, session_id: str, role: str, content: str,
                       intent: str = "", agent_tasks: str = "", latency_ms: float = 0) -> int:
        """创建消息记录"""
        self.cursor.execute(self._q("""
            INSERT INTO messages (session_id, role, content, intent, agent_tasks, latency_ms)
            VALUES (?, ?, ?, ?, ?, ?)
        """), (session_id, role, content, intent, agent_tasks, latency_ms))
        self.conn.commit()
        return self.cursor.lastrowid

    def get_session_messages(self, session_id: str, limit: int = 50) -> List[Dict]:
        """获取会话消息"""
        self.cursor.execute(
            self._q("SELECT * FROM messages WHERE session_id = ? ORDER BY created_at ASC LIMIT ?"),
            (session_id, limit)
        )
        return [dict(row) for row in self.cursor.fetchall()]

    # ========== Agent执行记录 ==========

    def create_agent_execution(self, request_id: str, session_id: str, intent: str,
                                task_type: str, model_used: str = "",
                                input_tokens: int = 0, output_tokens: int = 0,
                                cost: float = 0, latency_ms: float = 0,
                                status: str = "pending", retry_count: int = 0,
                                error_message: str = "") -> int:
        """创建Agent执行记录"""
        self.cursor.execute(self._q("""
            INSERT INTO agent_executions (request_id, session_id, intent, task_type,
                model_used, input_tokens, output_tokens, cost, latency_ms, status,
                retry_count, error_message)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """), (request_id, session_id, intent, task_type, model_used,
              input_tokens, output_tokens, cost, latency_ms, status,
              retry_count, error_message))
        self.conn.commit()
        return self.cursor.lastrowid

    def update_agent_execution(self, exec_id: int, status: str = "",
                                input_tokens: int = 0, output_tokens: int = 0,
                                cost: float = 0, latency_ms: float = 0,
                                retry_count: int = 0, error_message: str = ""):
        """更新Agent执行记录"""
        updates = []
        params = []
        if status:
            updates.append("status = ?")
            params.append(status)
        if input_tokens:
            updates.append("input_tokens = ?")
            params.append(input_tokens)
        if output_tokens:
            updates.append("output_tokens = ?")
            params.append(output_tokens)
        if cost:
            updates.append("cost = ?")
            params.append(cost)
        if latency_ms:
            updates.append("latency_ms = ?")
            params.append(latency_ms)
        if retry_count:
            updates.append("retry_count = ?")
            params.append(retry_count)
        if error_message:
            updates.append("error_message = ?")
            params.append(error_message)

        if not updates:
            return

        params.append(exec_id)
        self.cursor.execute(
            self._q(f"UPDATE agent_executions SET {', '.join(updates)} WHERE id = ?"),
            params
        )
        self.conn.commit()

    # ========== 评估操作 ==========

    def create_evaluation(self, message_id: int, user_id: int = 0,
                          auto_score: float = 0, user_score: float = 0,
                          user_feedback: str = "", intent_accuracy: float = 0,
                          task_completion: float = 0, response_quality: float = 0) -> int:
        """创建评估记录"""
        self.cursor.execute(self._q("""
            INSERT INTO evaluations (message_id, user_id, auto_score, user_score,
                user_feedback, intent_accuracy, task_completion, response_quality)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """), (message_id, user_id, auto_score, user_score, user_feedback,
              intent_accuracy, task_completion, response_quality))
        self.conn.commit()
        return self.cursor.lastrowid

    # ========== 监控指标操作 ==========

    def create_metric(self, metric_name: str, metric_value: float,
                      labels: Optional[Dict] = None) -> int:
        """创建监控指标记录"""
        labels_json = json.dumps(labels, ensure_ascii=False) if labels else "{}"
        self.cursor.execute(self._q("""
            INSERT INTO metrics (metric_name, metric_value, labels_json)
            VALUES (?, ?, ?)
        """), (metric_name, metric_value, labels_json))
        self.conn.commit()
        return self.cursor.lastrowid

    def query_metrics(self, metric_name: str = "", limit: int = 100,
                      since: str = "") -> List[Dict]:
        """查询监控指标"""
        sql = "SELECT * FROM metrics WHERE 1=1"
        params = []

        if metric_name:
            sql += " AND metric_name = ?"
            params.append(metric_name)

        if since:
            sql += " AND timestamp >= ?"
            params.append(since)

        sql += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        self.cursor.execute(self._q(sql), params)
        return [dict(row) for row in self.cursor.fetchall()]

    def aggregate_metrics(self, metric_name: str, interval: str = "hour") -> List[Dict]:
        """
        聚合监控指标

        Args:
            metric_name: 指标名称
            interval: 聚合间隔 (hour/day)

        Returns:
            聚合结果列表
        """
        if self.use_mysql:
            if interval == "day":
                date_format = "%Y-%m-%d"
            else:
                date_format = "%Y-%m-%d %H:00"
            sql = f"""
                SELECT
                    DATE_FORMAT(timestamp, %s) as period,
                    COUNT(*) as count,
                    AVG(metric_value) as avg_value,
                    MIN(metric_value) as min_value,
                    MAX(metric_value) as max_value,
                    SUM(metric_value) as sum_value
                FROM metrics
                WHERE metric_name = %s
                GROUP BY period
                ORDER BY period DESC
                LIMIT 100
            """
            self.cursor.execute(sql, (date_format, metric_name))
        else:
            if interval == "day":
                strftime_fmt = "%Y-%m-%d"
            else:
                strftime_fmt = "%Y-%m-%d %H:00"
            self.cursor.execute(f"""
                SELECT
                    strftime('{strftime_fmt}', timestamp) as period,
                    COUNT(*) as count,
                    AVG(metric_value) as avg_value,
                    MIN(metric_value) as min_value,
                    MAX(metric_value) as max_value,
                    SUM(metric_value) as sum_value
                FROM metrics
                WHERE metric_name = ?
                GROUP BY period
                ORDER BY period DESC
                LIMIT 100
            """, (metric_name,))

        return [dict(row) for row in self.cursor.fetchall()]

    def cleanup_old_metrics(self, days: int = 30) -> int:
        """清理过期监控指标"""
        self.cursor.execute(self._q(
            "DELETE FROM metrics WHERE timestamp < datetime('now', ?)"
        ), (f"-{days} days",))
        deleted = self.cursor.rowcount
        self.conn.commit()
        return deleted

    def close(self):
        """关闭连接"""
        if self.conn:
            self.conn.close()
            logger.info("数据库连接已关闭")


# 单例
_db_service: Any = None


def get_db_service() -> DatabaseService:
    """获取数据库服务单例"""
    global _db_service
    if _db_service is None:
        _db_service = DatabaseService()
    return _db_service
